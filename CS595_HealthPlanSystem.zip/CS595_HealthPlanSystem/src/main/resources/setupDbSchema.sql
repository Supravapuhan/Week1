delimiter ;
DROP SCHEMA IF EXISTS `cs595_healthplandb`; 
CREATE SCHEMA `cs595_healthplandb` ;
use `cs595_healthplandb`;


