package org.npu.healthplan.resthandlers;

import javax.ws.rs.Path;

@Path("/planrestapp")
public class SubscriberRestHandler {

}
