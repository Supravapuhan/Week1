package org.npu.healthplan.dao.hibernate;

import org.npu.healthplan.dao.HealthPlanSubscrDao;

public class SubscriberDaoHibernateImpl implements HealthPlanSubscrDao {

}
