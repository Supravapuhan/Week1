package org.npu.healthplan.domain;

public class HealthPlanSubscr {

}
