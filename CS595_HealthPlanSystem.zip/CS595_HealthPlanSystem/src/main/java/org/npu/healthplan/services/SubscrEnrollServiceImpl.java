package org.npu.healthplan.services;

public class SubscrEnrollServiceImpl implements SubscrEnrollService {

}
