package org.npu.healthplan.dao;

public interface HealthPlanSubscrDao {

}
