package org.npu.healthplan.services;

public interface SubscrEnrollService {

}
